/* written by marekm@linux.org.pl, hardly worth copyrighting :-) */

#include <stdlib.h>

void
abort(void)
{
    for (;;);
}
