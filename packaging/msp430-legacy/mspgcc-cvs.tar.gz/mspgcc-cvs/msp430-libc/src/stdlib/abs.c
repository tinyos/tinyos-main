/* written by marekm@linux.org.pl, hardly worth copyrighting :-) */

#include <stdlib.h>

int
abs(int x)
{
    return (x < 0) ? -x : x;
}
