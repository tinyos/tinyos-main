/* written by marekm@linux.org.pl, hardly worth copyrighting :-) */

#include <errno.h>

int errno;
