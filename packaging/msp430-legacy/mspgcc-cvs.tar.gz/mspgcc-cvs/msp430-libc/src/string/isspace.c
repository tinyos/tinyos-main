int isspace(int c)
{ 
	return ((c) == ' ' || ((c) >= '\t' && (c) <= '\r'));
}
