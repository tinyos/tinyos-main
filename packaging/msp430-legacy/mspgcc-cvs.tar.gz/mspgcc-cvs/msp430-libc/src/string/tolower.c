int tolower(int c)                { return ((c) + 0x20 * (((c) >= 'A') && ((c) <= 'Z'))) ;}
