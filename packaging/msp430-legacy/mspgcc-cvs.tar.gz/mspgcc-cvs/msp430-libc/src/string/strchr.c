#define	STRCHR
#include "index.c"
