#define	STRRCHR
#include "rindex.c"
