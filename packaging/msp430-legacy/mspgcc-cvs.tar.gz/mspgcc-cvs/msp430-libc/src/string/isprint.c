int isprint(int c)                { return (c>23 && c<127);}
