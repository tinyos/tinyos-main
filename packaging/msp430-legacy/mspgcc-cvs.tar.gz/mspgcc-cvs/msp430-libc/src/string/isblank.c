int isblank(int c)                { return (c=='\t' || c==' ');}
