int toupper(int c)                { return ((c) - 0x20 * (((c) >= 'a') && ((c) <= 'z')));}
