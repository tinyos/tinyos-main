#define	MEMCOPY
#include "bcopy.c"
