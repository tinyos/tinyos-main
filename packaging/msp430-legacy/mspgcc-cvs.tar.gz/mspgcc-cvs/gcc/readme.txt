For 3.x the mismatch between the numbering of GCC and these directories is a
historical accident.

For example to build "gcc 3.2.3", the patches have to be taken from "gcc-3.3"
in this CVS repository.

For gcc-4.0.2 the directory name is correct
