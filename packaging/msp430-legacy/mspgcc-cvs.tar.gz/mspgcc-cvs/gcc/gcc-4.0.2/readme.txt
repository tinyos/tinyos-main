This directory contains files for patching against gcc-4.0.2

Either copy the files from here ontop of the official gcc-4.0.2 distribution, 
or use the patch file.

This is work in progress

Peter Jansen, 2006-01-28
