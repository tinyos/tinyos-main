This directory contains files for patching against gcc-4.1.1.

Copy the files from here on top of the official gcc-4.1.1 distribution.

This is work in progress!

Chris Cole
cole@coledd.com
2006-06-14

